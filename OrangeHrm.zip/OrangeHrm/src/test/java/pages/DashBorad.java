package pages;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class DashBorad {
	WebDriver driver;
	public DashBorad(WebDriver driver) {
		this.driver=driver;
		
	}
	 public void launch() {
		 System.setProperty("webdriver.chrome.driver","D:\\Selenium jars\\Chrome driver\\chromedriver.exe");
			System.setProperty("webdriver.driver.in","C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe");
			driver = new ChromeDriver();
		    driver.manage().window().maximize();
		 
		 
	 }
	 public void  Home_page() {
	   		driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
	     }
	 public void loginData() throws InterruptedException, IOException {
		  
		driver.findElement(By.xpath("//*[@id='txtUsername' and @name='txtUsername']")).sendKeys("Admin");
		driver.findElement(By.xpath("//*[@id='txtPassword' and @name='txtPassword']")).sendKeys("admin123");
		driver.findElement(By.xpath("//*[@id='btnLogin' and @name='Submit']")).click();
		System.out.println(driver.getTitle());
	}
	
		
	public void Dashboard_Screenshot() throws IOException  {
		
		TakesScreenshot ts=(TakesScreenshot)(driver);
		File source=ts.getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(source ,new File("C:\\Users\\BLTuser.BLT0199\\eclipse-workspace\\OrangeHrm\\ScreenShot\\ScreenShot1.jpg"));
		
	}

}
